__name__ = 'CFPy'
__author__ = 'Torsten Noffz, Max G. Rudolph'
major = 1
minor = 0
__version__ = '{:d}.{:d}'.format(major, minor)

from .cfp import *
from .utils import *